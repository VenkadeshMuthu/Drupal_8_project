<?php
/**
 * @file
 * Definition of Drupal\devel_generate\DevelGenerateException.
 */
namespace Drupal\devel_generate;

use Drupal\Component\Plugin\Exception;

/**
 * DevelGenerateException extending Generic Plugin exception class.
 */
class DevelGenerateException extends \Exception {

}
